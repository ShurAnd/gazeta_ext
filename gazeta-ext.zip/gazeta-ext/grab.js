// Выполняется на странице со статьёй (после Readability.js).
// Возвращает {title, url, site, date, paragraphs} или {error}.
(() => {
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim();
  const meta = (q) => {
    const el = document.querySelector(q);
    return el ? norm(el.getAttribute("content")) : "";
  };

  const site = meta('meta[property="og:site_name"]') || location.hostname.replace(/^www\./, "");
  let date = "";
  const published =
    meta('meta[property="article:published_time"]') ||
    meta('meta[itemprop="datePublished"]') ||
    meta('meta[name="mediator_published_time"]');
  if (published) {
    const d = new Date(published);
    if (!isNaN(d)) {
      const p = (n) => String(n).padStart(2, "0");
      date = `${p(d.getDate())}.${p(d.getMonth() + 1)}.${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
    }
  }

  const h1 = document.querySelector("h1");
  let title = norm(h1 && h1.textContent) || meta('meta[property="og:title"]') || norm(document.title);
  let paragraphs = [];

  // 1. Если человек выделил текст мышью — берём именно его.
  const selection = String(window.getSelection() || "");
  if (norm(selection).length >= 200) {
    paragraphs = selection.split(/\n+/).map(norm).filter(Boolean);
  } else {
    // 2. Иначе выделяем статью автоматически (тот же алгоритм, что в «режиме чтения» Firefox).
    let article = null;
    try {
      article = new Readability(document.cloneNode(true), { serializer: (el) => el }).parse();
    } catch (e) {
      article = null;
    }
    if (article && article.content) {
      const blocks = "p, li, blockquote, h2, h3, h4, pre";
      for (const el of article.content.querySelectorAll(blocks)) {
        if (el.querySelector(blocks)) continue; // берём только «листья», чтобы не было повторов
        const t = norm(el.textContent);
        if (t.length > 1 && t !== paragraphs[paragraphs.length - 1]) paragraphs.push(t);
      }
      if (!paragraphs.length) {
        paragraphs = (article.textContent || "").split(/\n+/).map(norm).filter(Boolean);
      }
      if (!title) title = norm(article.title);
    }
  }

  const length = paragraphs.reduce((n, p) => n + p.length, 0);
  if (length < 150) {
    return { error: "Не удалось найти текст статьи. Выделите нужный текст мышью и нажмите кнопку ещё раз." };
  }
  // заголовок часто повторяется первым абзацем
  if (paragraphs[0] === title) paragraphs.shift();
  return { title, url: location.href.split("#")[0], site, date, paragraphs };
})();
