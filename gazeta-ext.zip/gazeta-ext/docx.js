// Формирование «газеты» в формате .docx без библиотек:
// docx — это zip-архив с XML-файлами, собираем его вручную.
const Docx = (() => {
  const PAGE =
    '<w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="850" w:right="850" w:bottom="1020" w:left="850" w:header="567" w:footer="567" w:gutter="0"/>';
  const TEXT_WIDTH = 11906 - 850 * 2;
  const NS =
    'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
  const HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';

  const esc = (s) =>
    String(s)
      .replace(/[\u0000-\u0008\u000A-\u001F￾￿]/g, " ")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  const run = (text, rpr = "") =>
    `<w:r>${rpr ? `<w:rPr>${rpr}</w:rPr>` : ""}<w:t xml:space="preserve">${esc(text)}</w:t></w:r>`;
  const para = (style, inner) => `<w:p><w:pPr><w:pStyle w:val="${style}"/></w:pPr>${inner}</w:p>`;

  function documentXml(p) {
    let b = "";
    // ---------- шапка (одна колонка) ----------
    b += para("Mast", run(p.title));
    if (p.subtitle.trim()) b += para("MastSub", run(p.subtitle));
    b += para("Info", `${run(p.date)}<w:r><w:tab/></w:r>${run("Материалов в номере: " + p.entries.length)}`);
    // «В номере» — анонс заголовков; этим же абзацем заканчивается одноколоночный раздел
    const toc =
      run("В НОМЕРЕ:  ", '<w:b/><w:i w:val="0"/>') + run(p.entries.map((e) => e.title).join("  •  "));
    b += `<w:p><w:pPr><w:pStyle w:val="Toc"/><w:sectPr><w:footerReference w:type="default" r:id="rId3"/>${PAGE}<w:cols w:space="720"/></w:sectPr></w:pPr>${toc}</w:p>`;

    // ---------- статьи (две колонки) ----------
    p.entries.forEach((e, i) => {
      b += para("Head", run(e.title));
      if (e.meta && e.meta.trim()) b += para("Meta", run(e.meta));
      let first = true;
      for (const t of e.paragraphs) {
        if (!t.trim()) continue;
        b += para(first ? "BodyFirst" : "Body", run(t.trim()));
        first = false;
      }
      if (i + 1 < p.entries.length) b += para("Rule", "");
    });
    return `${HEAD}<w:document ${NS}><w:body>${b}<w:sectPr><w:footerReference w:type="default" r:id="rId3"/><w:type w:val="continuous"/>${PAGE}<w:cols w:num="2" w:space="454" w:sep="1"/></w:sectPr></w:body></w:document>`;
  }

  function stylesXml() {
    const font = (f) => `<w:rFonts w:ascii="${f}" w:hAnsi="${f}" w:cs="${f}"/>`;
    const serif = font("Times New Roman"), display = font("Georgia"), sans = font("Arial");
    const size = (n) => `<w:sz w:val="${n}"/><w:szCs w:val="${n}"/>`;
    const style = (id, ppr, rpr) =>
      `<w:style w:type="paragraph" w:customStyle="1" w:styleId="${id}"><w:name w:val="${id}"/><w:basedOn w:val="Normal"/><w:pPr>${ppr}</w:pPr><w:rPr>${rpr}</w:rPr></w:style>`;
    const body = '<w:widowControl/><w:spacing w:before="0" w:after="0" w:line="254" w:lineRule="auto"/>';
    return (
      `${HEAD}<w:styles ${NS}><w:docDefaults><w:rPrDefault><w:rPr>${serif}${size(20)}<w:lang w:val="ru-RU" w:eastAsia="ru-RU" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>` +
      // название газеты
      style("Mast", '<w:pBdr><w:top w:val="single" w:sz="24" w:space="6" w:color="000000"/></w:pBdr><w:suppressAutoHyphens/><w:spacing w:before="0" w:after="0"/><w:jc w:val="center"/>', `${display}<w:b/>${size(88)}`) +
      style("MastSub", '<w:suppressAutoHyphens/><w:spacing w:before="20" w:after="120"/><w:jc w:val="center"/>', `${sans}<w:caps/><w:color w:val="444444"/><w:spacing w:val="60"/>${size(15)}`) +
      // строка с датой между двумя линейками
      style("Info", `<w:pBdr><w:top w:val="single" w:sz="6" w:space="3" w:color="000000"/><w:bottom w:val="double" w:sz="6" w:space="3" w:color="000000"/></w:pBdr><w:tabs><w:tab w:val="right" w:pos="${TEXT_WIDTH}"/></w:tabs><w:suppressAutoHyphens/><w:spacing w:before="0" w:after="160"/>`, `${sans}<w:b/>${size(16)}`) +
      style("Toc", '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="6" w:color="000000"/></w:pBdr><w:spacing w:before="0" w:after="200" w:line="252" w:lineRule="auto"/><w:jc w:val="both"/>', `<w:i/>${size(19)}`) +
      // заголовок статьи
      style("Head", '<w:keepNext/><w:keepLines/><w:suppressAutoHyphens/><w:spacing w:before="60" w:after="50" w:line="228" w:lineRule="auto"/>', `${display}<w:b/>${size(30)}`) +
      style("Meta", '<w:keepNext/><w:suppressAutoHyphens/><w:spacing w:before="0" w:after="90"/>', `${sans}<w:caps/><w:color w:val="666666"/><w:spacing w:val="10"/>${size(14)}`) +
      style("BodyFirst", `${body}<w:jc w:val="both"/>`, "") +
      style("Body", `${body}<w:ind w:firstLine="284"/><w:jc w:val="both"/>`, "") +
      // линейка между статьями
      style("Rule", '<w:pBdr><w:bottom w:val="single" w:sz="4" w:space="1" w:color="808080"/></w:pBdr><w:spacing w:before="60" w:after="140" w:line="120" w:lineRule="exact"/>', size(8)) +
      style("Foot", '<w:pBdr><w:top w:val="single" w:sz="4" w:space="4" w:color="808080"/></w:pBdr><w:jc w:val="center"/>', `${sans}<w:color w:val="666666"/>${size(15)}`) +
      "</w:styles>"
    );
  }

  function footerXml(p) {
    const fld = (t) => `<w:r><w:fldChar w:fldCharType="${t}"/></w:r>`;
    return `${HEAD}<w:ftr ${NS}><w:p><w:pPr><w:pStyle w:val="Foot"/></w:pPr>${run(`${p.title}  •  ${p.date}  •  стр. `)}${fld("begin")}<w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>${fld("separate")}<w:r><w:t>1</w:t></w:r>${fld("end")}</w:p></w:ftr>`;
  }

  // ---------- минимальный zip (без сжатия) ----------
  const CRC = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crc32(bytes) {
    let c = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) c = CRC[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }
  function zip(files) {
    const enc = new TextEncoder();
    const parts = [], central = [];
    let offset = 0;
    const u16 = (n) => [n & 255, (n >>> 8) & 255];
    const u32 = (n) => [n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255];
    for (const [name, text] of files) {
      const nameB = enc.encode(name), data = enc.encode(text);
      const common = [
        ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0x21),
        ...u32(crc32(data)), ...u32(data.length), ...u32(data.length), ...u16(nameB.length), ...u16(0),
      ];
      const local = new Uint8Array([...u32(0x04034b50), ...common]);
      parts.push(local, nameB, data);
      central.push(
        new Uint8Array([...u32(0x02014b50), ...u16(20), ...common, ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)]),
        nameB
      );
      offset += local.length + nameB.length + data.length;
    }
    const cdSize = central.reduce((n, a) => n + a.length, 0);
    const end = new Uint8Array([
      ...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length),
      ...u32(cdSize), ...u32(offset), ...u16(0),
    ]);
    return [...parts, ...central, end];
  }

  /** p = {title, subtitle, date, entries:[{title, meta, paragraphs:[...]}]} -> массив частей для Blob */
  function build(p) {
    const REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    const CT = "application/vnd.openxmlformats-officedocument.wordprocessingml";
    return zip([
      ["[Content_Types].xml", `${HEAD}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="${CT}.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="${CT}.styles+xml"/><Override PartName="/word/settings.xml" ContentType="${CT}.settings+xml"/><Override PartName="/word/footer1.xml" ContentType="${CT}.footer+xml"/></Types>`],
      ["_rels/.rels", `${HEAD}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${REL}/officeDocument" Target="word/document.xml"/></Relationships>`],
      ["word/document.xml", documentXml(p)],
      ["word/styles.xml", stylesXml()],
      // автоматические переносы — иначе узкие колонки с выключкой по ширине выглядят «дырявыми»
      ["word/settings.xml", `${HEAD}<w:settings ${NS}><w:autoHyphenation/><w:hyphenationZone w:val="357"/></w:settings>`],
      ["word/footer1.xml", footerXml(p)],
      ["word/_rels/document.xml.rels", `${HEAD}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${REL}/styles" Target="styles.xml"/><Relationship Id="rId2" Type="${REL}/settings" Target="settings.xml"/><Relationship Id="rId3" Type="${REL}/footer" Target="footer1.xml"/></Relationships>`],
    ]);
  }

  return { build };
})();
if (typeof module === "object") module.exports = Docx;
